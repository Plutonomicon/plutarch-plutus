# `plutarch-orphanage`

A collection of orphan QuickCheck instances for Plutus ledger API types.
